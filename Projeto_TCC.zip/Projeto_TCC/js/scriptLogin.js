document.getElementById("recSenha").addEventListener('click', () => {
    console.log("Sua Senha é: hello World!")
});

