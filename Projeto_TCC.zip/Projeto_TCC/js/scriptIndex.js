document.getElementById("login").addEventListener('click', () => {
    window.location.href = 'login.html';
});